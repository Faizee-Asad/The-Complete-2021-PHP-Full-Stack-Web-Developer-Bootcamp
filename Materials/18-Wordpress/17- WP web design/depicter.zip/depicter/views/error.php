<?php
/**
 * An example view.
 *
 * Layout: layouts/example.php
 *
 * @package Depicter
 */

?>
<div class="depicter__view">
	Error occured!
</div>
