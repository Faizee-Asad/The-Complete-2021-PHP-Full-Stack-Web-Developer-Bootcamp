<?php
/**
 * An example view.
 *
 * @package Depicter
 */

?>
<div class="msp__view">
	<?php echo "Editor in preview mode."; ?>
</div>
