<?php
/**
 * Admin dashboard view.
 *
 * @package Depicter
 */

?>
<div class="master-dashboard-content ">
	<?php \Depicter::render( 'admin/dashboard/partials/content.php', []); ?>
</div>
