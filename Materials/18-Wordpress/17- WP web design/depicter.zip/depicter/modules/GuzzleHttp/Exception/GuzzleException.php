<?php

namespace Depicter\GuzzleHttp\Exception;

use Depicter\Psr\Http\Client\ClientExceptionInterface;

interface GuzzleException extends ClientExceptionInterface
{
}
