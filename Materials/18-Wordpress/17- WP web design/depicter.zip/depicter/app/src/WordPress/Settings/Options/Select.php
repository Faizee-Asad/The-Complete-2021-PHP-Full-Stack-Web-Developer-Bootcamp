<?php

namespace Depicter\WordPress\Settings\Options;

use Depicter\WordPress\Settings\Options\OptionAbstract;

class Select extends OptionAbstract
{
    public $view = 'select';
}