<?php
namespace Depicter\WordPress\Settings\Options;

use Depicter\WordPress\Settings\Options\OptionAbstract;

class Choices extends OptionAbstract
{
    public $view = 'choices';
}
