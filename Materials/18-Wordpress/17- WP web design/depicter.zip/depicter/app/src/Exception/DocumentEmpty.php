<?php
namespace Depicter\Exception;

class DocumentEmpty extends EntityException {}

