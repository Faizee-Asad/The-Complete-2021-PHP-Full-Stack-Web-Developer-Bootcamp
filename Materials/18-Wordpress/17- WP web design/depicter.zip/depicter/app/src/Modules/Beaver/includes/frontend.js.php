jQuery(function($) {
	<?php if ( $settings->document_id ) : ?>
		Depicter.initAll();
	<?php endif; ?>
});
