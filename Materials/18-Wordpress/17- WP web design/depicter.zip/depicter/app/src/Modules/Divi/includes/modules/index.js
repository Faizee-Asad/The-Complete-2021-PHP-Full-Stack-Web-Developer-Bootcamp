// Internal Dependencies
import Divi_Depicter_Module from './depicter/depicter';

export default [
    Divi_Depicter_Module,
];