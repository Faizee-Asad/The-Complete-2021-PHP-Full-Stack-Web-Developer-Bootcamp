<?php
namespace Depicter\Document\Models\Common;

class Color extends Measure\Base
{
	/**
	 * @var string
	 */
	public $tablet;

	/**
	 * @var string
	 */
	public $mobile;

}
