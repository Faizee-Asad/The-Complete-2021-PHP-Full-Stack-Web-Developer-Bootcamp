<?php
namespace Depicter\Document\Models\Common\Styles;


class BaseColor
{
	/**
	 * @var string
	 */
	public $default;

	/**
	 * @var string
	 */
	public $tablet;

	/**
	 * @var string
	 */
	public $mobile;

}
