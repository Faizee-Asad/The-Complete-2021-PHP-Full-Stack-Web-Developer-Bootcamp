<?php
namespace Depicter\Document\Models\Options;


use Depicter\Document\Models\Common\Measure\Base;

class Unit extends Base
{
}
