<?php
namespace Depicter\Document\Models\Common\Animation;


class States
{
	/**
	 * @var Base
	 */
	public $default;

	/**
	 * @var Base
	 */
	public $tablet;

	/**
	 * @var Base
	 */
	public $mobile;
}
