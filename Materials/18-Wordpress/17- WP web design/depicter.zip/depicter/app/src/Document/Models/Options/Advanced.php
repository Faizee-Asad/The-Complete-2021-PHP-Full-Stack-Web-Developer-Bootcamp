<?php
namespace Depicter\Document\Models\Options;


class Advanced
{
	/**
	 * @var string
	 */
	public $className;

	/**
	 * @var string
	 */
	public $customStyle;
}
