<?php
namespace Depicter\Media\Image;

class ImageEditorException extends \Exception {}
