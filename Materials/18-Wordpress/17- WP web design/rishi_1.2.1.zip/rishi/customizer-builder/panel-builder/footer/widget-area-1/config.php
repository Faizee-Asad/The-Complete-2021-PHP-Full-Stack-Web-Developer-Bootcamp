<?php

$config = [
    'name' => __('Widget 1', 'rishi'),
    'visibilityKey' => 'footer_hide_widget_one',
    // 'clone' => true,
];
