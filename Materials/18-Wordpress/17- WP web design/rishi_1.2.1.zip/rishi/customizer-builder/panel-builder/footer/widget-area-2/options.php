<?php

$options = rishi__cb_customizer_get_options(
	\RISHI_CUSTOMIZER_BUILDER_DIR__ . '/panel-builder/footer/widget-area-1/options.php',
	[
		'sidebarId' => 'footer-two',
		'id'		=> '_two'
	],
	false
);
