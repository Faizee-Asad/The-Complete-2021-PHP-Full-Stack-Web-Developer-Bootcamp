<?php

$config = [
	'name' => __('Top Row', 'rishi'),
	'typography_keys' => ['footerWidgetsTitleFont', 'footerWidgetsFont'],
];
