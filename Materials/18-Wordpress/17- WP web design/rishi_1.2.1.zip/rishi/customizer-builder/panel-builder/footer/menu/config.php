<?php

$config = [
	'name' => __('Footer Menu', 'rishi'),
	'visibilityKey' => 'footer_hide_menu_one',
	'typography_keys' => ['footerMenuFont'],
	'selective_refresh' => ['menu']
];
