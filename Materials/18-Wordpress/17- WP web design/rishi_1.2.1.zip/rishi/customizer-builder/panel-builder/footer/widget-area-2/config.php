<?php

$config = [
    'name' => __('Widget 2', 'rishi'),
    'visibilityKey' => 'footer_hide_widget_two',
    // 'clone' => true,
];
