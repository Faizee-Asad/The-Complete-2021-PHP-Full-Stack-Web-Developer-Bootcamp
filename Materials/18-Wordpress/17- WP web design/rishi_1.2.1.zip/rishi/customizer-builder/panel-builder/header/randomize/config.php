<?php
$config = [
	'name'              => __('Random Posts', 'rishi'),
	'visibilityKey'     => 'header_hide_randomize',
	'typography_keys'   => ['headerRandomizeFont'],
	'selective_refresh' => ['header_randomize_icon_type','header_randomize_ed_title', 'header_randomize_label'],
];