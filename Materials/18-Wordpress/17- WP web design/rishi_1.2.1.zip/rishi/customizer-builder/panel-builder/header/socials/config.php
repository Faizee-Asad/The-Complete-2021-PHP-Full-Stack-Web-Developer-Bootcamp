<?php

$config = [
	'name' => __('Socials', 'rishi'),
	'clone' => true,
	'visibilityKey' 	=> 'header_hide_social',
];
