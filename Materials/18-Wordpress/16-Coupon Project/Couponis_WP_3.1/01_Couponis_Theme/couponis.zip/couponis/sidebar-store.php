<?php
if ( is_active_sidebar( 'store' ) ){
	dynamic_sidebar( 'store' );
}
?>