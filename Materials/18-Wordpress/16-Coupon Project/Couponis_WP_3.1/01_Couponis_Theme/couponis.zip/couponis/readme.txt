Couponis premium WP blogging theme - by SpoonThemes
http://themeforest.net/user/spoonthemes