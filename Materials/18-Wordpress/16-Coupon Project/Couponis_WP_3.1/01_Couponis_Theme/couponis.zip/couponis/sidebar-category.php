<?php
if ( is_active_sidebar( 'category' ) ){
	dynamic_sidebar( 'category' );
}
?>