<?php
if ( is_active_sidebar( 'blog' ) ){
	dynamic_sidebar( 'blog' );
}
?>