<?php
if ( is_active_sidebar( 'search' ) ){
	dynamic_sidebar( 'search' );
}
?>