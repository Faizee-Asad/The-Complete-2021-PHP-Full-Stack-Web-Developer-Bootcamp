<?php
if ( is_active_sidebar( 'account' ) ){
	dynamic_sidebar( 'account' );
}
?>