<a href="javascript:;" class="to_top btn">
	<span class="fa fa-angle-up"></span>
</a>

<?php 
/*
This loads new files couponis-footer.php loaded from root of the plugin
*/
do_action('couponis_footer');
?>

<?php wp_footer(); ?>
</body>
</html>