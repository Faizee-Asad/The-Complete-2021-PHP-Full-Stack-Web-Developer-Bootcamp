<?php
if ( is_active_sidebar( 'submit' ) ){
	dynamic_sidebar( 'submit' );
}
?>